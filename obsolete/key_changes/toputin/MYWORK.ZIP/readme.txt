1999.04.01

Hi,
I know that is difficult to work via internet, but I would like to try!
So I am sending to you my modification to Key to give the possibility to have different
bodies associated with a player...
It's only a beginning, so I would like to share with you my ideas...

If you want to try what I have done follow this:

> load Humanoid <playername>_body
> cd /players
> set <playername>.body /<path_to_loaded_object>/<playername>_body

> create sword objects.Weapon
> wield sword
> i

You will hopefully see that you have a sword wielded in the right hand.


Why in the last days no-one in the mailing list is responding to my mails?
Are you too busy? Do you want me to continue to send my ideas or not?

Subtle: I was unable to contact you via ICQ because I can't find you on-line...
        my ICQ # is 34519671
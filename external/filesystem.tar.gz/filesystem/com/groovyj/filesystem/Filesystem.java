/*
 * Filesystem.java
 *
 * Created on August 17, 1999, 11:44 AM
 */
 
package com.groovyj.filesystem;
import java.util.*;
import java.io.*;

/**
 * Filesystem is a minifilesystem where you can store records (files), with
 * deleted space being managed somewhat efficiently. It's particularly useful
 * when your record size is less than about 10k, generally on the order of 100
 * bytes, and they are subject to
 * getting deleted all the time.
 * <P>
 * Got a comment about this class? Found a bug? Got an enhancement?
 * Just want to say hi?  Visit the <a href=
 * http://members.xoom.com/groovyjava/Filesystem/index.html>
 * Groovy Java Filesystem Project Home Page</a>.
 * <P>
 * Visit the <a href=http://members.xoom.com/groovyjava/index.html>
 * Groovy Java Home Page</a> for information about other Groovy Java
 * open source projects.
 * <P>
 * This class is covered by the <a href=http://www.gnu.org/copyleft/gpl.html>
 * GNU General Public License (GPL)</a>.
 *
 * @author      Robert Baruch (groovyjava@xoommail.com)
 * @version     1.0, 8 September 1999
 */
public class Filesystem extends Object {
  long freeOffset;
  RandomAccessFile file;

  // Imagine a Filesystem as consisting of a whole bunch of segments of
  // equal size. Files are chains of segments, and there is a free "file",
  // which is just a chain of freed segments.
  //
  // Now let the segments be of variable size, and you get this class.
  
  /** Creates a new Filesystem or opens an existing one.
  *
  * @ param name the name of the file containing the Filesystem
  */
  public Filesystem(String name) throws IOException {
    file = new RandomAccessFile(name, "rw");
    if (file.length()<8) {
      freeOffset = 0;
      file.writeLong(0);
    } else
      freeOffset = file.readLong();
  }
  
  /** Returns the number of bytes in this filesystem.
  *
  * @ return the number of bytes in this filesystem.
  */
  public long length() throws IOException {
    return file.length();
  }
  
  /** Closes this filesystem
  *
  * @see java.io.File#close()
  */
  
  public void close() throws IOException {
    file.close();
  }
  
  /** Opens a new file in the filesystem.
  *
  * @return a Filesystem.File that must be used to access the new file.
  * @exception IOException a new file couldn't be created.
  */
  
  public File open() throws IOException {
    return new File();
  }
  
  /** Opens an existing file in the filesystem, given the offset into
  * the filesystem at which the file begins.
  *
  * @param offset the offset into the filesystem at which the file begins.
  * @return a Filesystem.File that must be used to access the file.
  * @exception IOException a new file couldn't be created.
  */
  public File open(long offset) throws IOException {
    return new File(offset);
  }
  

  /**
  * Filesystem.File is a class containing all the operations you can
  * do to a file in the Filesystem.
  *
  */
  
  public class File {
    long begin = 0;
    int currOffset;
    ArrayList segments = new ArrayList();
    int length;
    int currSegment;
    int segFileOffset;
    
    class Segment {
      public long offset;
      public int segSize;
      public int dataSize;
      public long nextSegment;
     
      public int headerSize() { return 16; }
      
      public Segment(long offset) throws IOException {
        this.offset = offset;
        file.seek(offset);
        byte[] header = new byte[headerSize()];
        file.read(header);
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(header));
        segSize = in.readInt();
        dataSize = in.readInt();
        nextSegment = in.readLong();
      }
      
      public Segment(long offset, int segSize, int dataSize,
          long nextSegment, long prevSegment) {
        this.offset = offset;
        this.segSize = segSize;
        this.dataSize = dataSize;
        this.nextSegment = nextSegment;
      }
      
      public Segment(Segment prevSegment, int desiredSize) 
          throws IOException {
        if (freeOffset!=0) {
          this.offset = freeOffset;
          file.seek(this.offset);
          byte[] header = new byte[headerSize()];
          file.read(header);
          DataInputStream in = new DataInputStream(new ByteArrayInputStream(header));
          this.segSize = in.readInt();
          in.readInt(); // dataSize
          freeOffset = in.readLong();
        } else {
          this.offset = file.length();
          this.segSize = desiredSize;
          freeOffset = 0;
        }
        this.dataSize = Math.min(desiredSize, segSize);
        this.nextSegment = 0;
        if (prevSegment!=null) {
          prevSegment.nextSegment = offset;
          prevSegment.writeHeader();
        }
        writeHeader();
        file.seek(0);
        file.writeLong(freeOffset);
      }
      
      public void writeHeader() throws IOException {
        file.seek(offset);
        ByteArrayOutputStream bout = new ByteArrayOutputStream(headerSize());
        DataOutputStream out = new DataOutputStream(bout);
        out.writeInt(segSize);
        out.writeInt(dataSize);
        out.writeLong(nextSegment);
        file.write(bout.toByteArray());
      }
      
      public String toString() {
        return "offset " + offset + " segSize " + segSize + " dataSize " +
          dataSize + " next " + nextSegment;
      }
    }
    
    File() { // create a new file
      currOffset = 0;
      currSegment = -1;
      segFileOffset = 0;
      length = 0;
      begin = -1;
    }
    
    File(long offset) throws IOException { // open an existing file
      begin = offset;
      
      Segment segment = new Segment(offset);
      
      segments.add(segment);
      length = segment.dataSize;
      while (segment.nextSegment!=0) {
        segment = new Segment(segment.nextSegment);
        segments.add(segment);
        length += segment.dataSize;
      }
      currSegment = 0;
      segFileOffset = 0;
      currOffset = 0;
    }
    
    /**
    * Get the offset at which this file begins. This is the only way a program
    * can open this file again.
    *
    * @return the offset of this file, or -1 if this file is new and hasn't
    * been written to.
    */
    
    public long getOffset() {
      return begin;
    }
       
    /**
    * Get the length, in bytes, of this file.
    *
    * @return the length, in bytes, of this file.
    */
    public int length() {
      return length;
    }
    
    /**
    * Get the file pointer, in bytes, of this file. The file pointer of this file
    * is the offset into this file at which the next write or read operation
    * will take place. The file pointer of a newly opened file is always 0.
    *
    * @return the file pointer of this file.
    */
    public int getFilePointer() {
      return currOffset;
    }
    
    /**
    * Move the file pointer to the given byte offset in this file. If the length
    * of this file is L, then you can move the file pointer anywhere between
    * 0 and L inclusive without throwing an IOException. Moving the file pointer
    * to L means that the next write operation will append to this file. If the
    * file pointer is at L, then the next read operation will fail since there
    * is nothing to read.
    *
    * @param offset the byte offset into the file to which to move the file
    * pointer.
    * @exception IOException the offset was negative or greater than the
    * length of this file.
    */
    
    public void seek(int offset) throws IOException {
      
      // We want to seek outside the file.  That's not allowed!
      
      if (offset<0 || offset>length)
        throw new IOException();
      
      // We want to seek to the end of the file.
      
      if (offset==length) {
        currOffset = offset;
        currSegment = segments.size()-1; // could be -1
        if (currSegment!=-1)
          segFileOffset = length-((Segment)segments.get(currSegment)).dataSize;
        
        // This is important! The segFileOffset must contain the file offset
        // of the beginning of the LAST segment in the file, while
        // currSegment must be -1. I'm thinking that we should just set
        // segFileOffset to length, and then change things around in
        // read and write, but I haven't analyzed the code well enough.
        
        currSegment = -1;
        return;
      }

      // Otherwise we want to seek somewhere in the existing file.

      if (offset<currOffset) {
        currSegment=0;
        currOffset=0;
        segFileOffset=0;
      }
      Segment seg = (Segment)segments.get(currSegment);
      
      // While the desired offset is beyond this segment, look at
      // the next segment and repeat.
      
      while (offset >= segFileOffset+seg.dataSize) {
        segFileOffset += seg.dataSize;
        currSegment++;
        seg = (Segment)segments.get(currSegment);
      }
      currOffset = offset;
    }
    
    /**
    * Write the given data to the file at the file pointer.
    *
    * @param data an array of bytes which will be written to this file.
    * @exception IOException writing the raw underlying filesystem failed.
    */
    
    public void write(byte[] data) throws IOException {
      int written = 0;
      
      while (written!=data.length) {
       
        // If there is a current segment, then write as much data
        // as we can into it.
        
        Segment seg = currSegment!=-1 ? (Segment)segments.get(currSegment) : null;
        
        if (currSegment!=-1) {
          int segPos = currOffset-segFileOffset;
          int amt = Math.min(data.length-written, seg.dataSize-segPos);

          if (amt>0) { // to prevent needless system calls
            file.seek(seg.offset+segPos+seg.headerSize());
            file.write(data, written, amt);
            written += amt;
          }
          seek(currOffset+amt); // Goes to the next segment if there is one
        }

        // If there's no current segment then...
        
        if (currSegment==-1 && written!=data.length) {
          
          // Get the last segment if there is one
          
          if (segments.size()!=0)
            seg = (Segment)segments.get(segments.size()-1);
          else
            seg = null;
          
          // If there's a hole in the last segment, fill it
          
          if (seg!=null && seg.segSize>seg.dataSize) {
            
            int newSize = Math.min(data.length-written, seg.segSize);
            
            // we increase the length of the file here so that when
            // we write the data the length will be correct.
            
            length += newSize - seg.dataSize;
            
            seg.dataSize = newSize;
            seg.writeHeader();
            currSegment = segments.size()-1;
            continue;
          }
          
          // allocate a new sector and chain it to the last sector if there is one
          
          seg = new Segment(seg, data.length-written);
          segments.add(seg);
          currSegment = segments.size()-1;
          if (length==0) // new file
            begin = seg.offset;
          segFileOffset = length;
          length += Math.min(data.length-written, seg.segSize);
        }
      } // while more data to write
      return;
    }

    /**
    * Read an amount of bytes starting at the file pointer,
    * and return an array filled with the bytes read.
    *
    * @param len the number of bytes to read.
    * @return an array of bytes containing the bytes read. The length of
    * the array may not be equal to len, and if no bytes could be read
    * (for example the file pointer is at the end of this file)
    * then the array will be of zero length.
    * @exception IOException reading the raw underlying filesystem failed.
    */
    public byte[] read(int len) throws IOException {
      int red = 0;
      byte[] data = new byte[len];

      while (red!=len) {
        
        // If there is a current segment, then read as much data
        // as we can from it.
        
        if (currSegment!=-1) {
          Segment seg = (Segment)segments.get(currSegment);
          int segPos = currOffset-segFileOffset;
          int amt = Math.min(data.length-red, seg.dataSize-segPos);
        
          file.seek(seg.offset+segPos+seg.headerSize());
          file.read(data, red, amt);
          red += amt;
          seek(currOffset+amt); // update all the pointers
        }
        
        // if we hit the end of the file, just return what we've
        // read (and that could be zero bytes.
        
        if (currSegment==-1) {
          byte[] retdata = new byte[red];
          System.arraycopy(data, 0, retdata, 0, red);
          return retdata;
        }
      }
      return data;
    }
    
    /**
    * Deletes this file entirely. Reclaims all the space used by this file.
    * This file becomes equivalent to a new file.
    *
    * @exception IOException the raw underlying filesystem couldn't be updated.
    */
    
    public void delete() throws IOException {
      if (begin==-1) // file was never written to
        return;
      
      Segment first = (Segment)segments.get(0);
      Segment last = (Segment)segments.get(segments.size()-1);

      last.nextSegment = freeOffset;
      last.writeHeader();
      freeOffset = first.offset;
      file.seek(0);
      file.writeLong(freeOffset);
      currOffset = 0;
      currSegment = -1;
      segFileOffset = 0;
      length = 0;
      begin = -1;
      segments = new ArrayList();
    }
    
    /**
    * Truncates this file at the file pointer. Any segments after the file pointer
    * are reclaimed as free space.
    *
    * @exception IOException the raw underlying filesystem couldn't be updated.
    */
    
    public void truncate() throws IOException {
      if (currSegment==-1)
        return;
      length = currOffset;
      
      // Right here is where we could create zero-length segments. This is
      // the Right Thing to do because if we seek(0) and then truncate,
      // we need to keep the first segment because otherwise the beginning
      // offset of the record might change.
      
      Segment seg = (Segment)segments.get(currSegment);
      seg.dataSize = currOffset-segFileOffset;
      seg.nextSegment = 0;
      seg.writeHeader();
      
      // If this segment is the last segment, then we just return.
      
      if (currSegment==segments.size()-1)
        return;
      
      // We need to add the segments that were removed to the free chain
      
      seg = (Segment)segments.get(segments.size()-1);
      seg.nextSegment = freeOffset;
      seg.writeHeader();
      if (currSegment != segments.size()) // first segment is not last segment
        seg = (Segment)segments.get(currSegment+1);
      freeOffset = seg.offset;
      file.seek(0);
      file.writeLong(freeOffset);
      
      // Now we just remove the segments from the segment list
      
      currSegment++;
      while (currSegment!=segments.size()-1)
        segments.remove(currSegment);
    }    
  }
  
  /**
  * Runs a bunch of tests. I run them one at a time and then
  * view the hex output of the resulting file to see if it makes sense.
  */
  
  public static void main(String args[]) throws Exception {
    Filesystem fs = new Filesystem("tmp.dat");
    String s = "012345678901234567890123456789";
    String t = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    File file1;
    
    // Write test
    
    file1 = fs.open();
    System.out.println("Write 30");
    file1.write(s.getBytes("ASCII"));
    System.out.println("Write 30");
    file1.write(s.getBytes("ASCII"));
        
    if (args[0].equals("1"))
      return;
    
    // Read test
    
    System.out.println("Seek 0");
    file1.seek(0);
    System.out.println("Read 15");
    System.out.println(new String(file1.read(15), "ASCII"));
    System.out.println("Read 100");
    System.out.println(new String(file1.read(100), "ASCII"));
    
    if (args[0].equals("2"))
      return;
    
    // Overwrite test

    System.out.println("Seek 0");
    file1.seek(0);
    System.out.println("Write 26");
    file1.write(t.getBytes("ASCII"));
    System.out.println("Write 26");
    file1.write(t.getBytes("ASCII"));
    
    if (args[0].equals("3"))
      return;
    
    // Append test
    
    System.out.println("Seek end");
    file1.seek(file1.length());
    System.out.println("Write 26");
    file1.write(t.getBytes("ASCII"));
    System.out.println("Seek 0");
    file1.seek(0);
    System.out.println("Read 15");
    System.out.println(new String(file1.read(15), "ASCII"));
    System.out.println("Read 100");
    System.out.println(new String(file1.read(100), "ASCII"));
    
    if (args[0].equals("4"))
      return;
    
    // Delete test
    
    System.out.println("Delete file");
    file1.delete();
    
    if (args[0].equals("5"))
      return;
    
    // Use free segments test
    
    file1 = fs.open();
    System.out.println("Write 26");
    file1.write(t.getBytes("ASCII"));
    System.out.println("Seek 0");
    file1.seek(0);
    System.out.println("Read 100");
    System.out.println(new String(file1.read(100), "ASCII"));
    System.out.println("Seek 15");
    file1.seek(15);
    System.out.println("Read 100");
    System.out.println(new String(file1.read(100), "ASCII"));
    
    if (args[0].equals("6"))
      return;
    
    // Truncate test
    
    System.out.println("Seek 15");
    file1.seek(15);
    System.out.println("Truncate");
    file1.truncate();
    System.out.println("Seek 0");
    file1.seek(0);
    System.out.println("Read 100");
    System.out.println(new String(file1.read(100), "ASCII")); 
    
    if (args[0].equals("7"))
      return;
    
    // Truncate at segment boundary test
    
    System.out.println("Write 30");
    file1.write(s.getBytes("ASCII"));
    System.out.println("Seek 30");
    file1.seek(30);
    System.out.println("Truncate at " + file1.getFilePointer());
    file1.truncate();
    System.out.println("Seek 0");
    file1.seek(0);
    System.out.println("Read 100");
    System.out.println(new String(file1.read(100), "ASCII")); 
    
    // Now we have a zero-length segment at the end.  Try to write it.
    
    System.out.println("Write 26: length " + file1.length() +
      " file pointer " + file1.getFilePointer());
    file1.write(t.getBytes("ASCII"));
    
    fs.close();
  }
}

// ========================================================================
// Copyright (c) 1997 Mort Bay Consulting (Australia) Pty. Ltd.
// $Id: T1.java,v 2.0 1998/08/07 05:14:11 gregw Exp $
// ========================================================================

package com.mortbay.Util.Test;

public class T1
{
    public int i;
    public Integer I;
    public String s;
}

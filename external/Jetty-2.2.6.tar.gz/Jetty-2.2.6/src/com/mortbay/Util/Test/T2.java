// ========================================================================
// Copyright (c) 1997 Mort Bay Consulting (Australia) Pty. Ltd.
// $Id: T2.java,v 2.0 1998/08/07 05:14:13 gregw Exp $
// ========================================================================

package com.mortbay.Util.Test;


public class T2
{
    public T1 t1;
    public T1[] a;
}

// ===========================================================================
// Copyright (c) 1996 Mort Bay Consulting Pty. Ltd. All rights reserved.
// $Id: Observed.java,v 2.0 1998/08/07 05:13:55 gregw Exp $
// ---------------------------------------------------------------------------

package com.mortbay.Util;

import java.util.*;

/* ======================================================================== */
/** Helpful extension to Observable.
 * NotifyObservers will set a changed first.
 */
public class Observed  extends Observable
{
    public void notifyObservers(Object arg)
    {
	setChanged();
	super.notifyObservers(arg);
    }

    public void notifyObservers()
    {
	setChanged();
	super.notifyObservers(null);
    }
}

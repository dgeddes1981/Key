// ===========================================================================
// Copyright (c) 1996 Mort Bay Consulting Pty. Ltd. All rights reserved.
// $Id: CompositeFactory.java,v 2.0 1998/08/07 05:16:03 gregw Exp $
// ---------------------------------------------------------------------------

package com.mortbay.HTML;
import java.io.*;
import java.util.*;

/* --------------------------------------------------------------------- */
/** Composite Factory
 * Abstract interface for production of composites
 */
public interface CompositeFactory
{
    public Composite newComposite();
}



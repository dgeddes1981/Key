// ===========================================================================
// Copyright (c) 1996 Mort Bay Consulting Pty. Ltd. All rights reserved.
// $Id: Tag.java,v 2.1 1999/09/04 23:58:38 gregw Exp $
// ---------------------------------------------------------------------------

package com.mortbay.HTML;
import java.io.*;
import java.util.*;

/* -------------------------------------------------------------------- */
/** HTML Tag Element
 * A Tag element is of the generic form &ltTAG attributes... &gt
 * @see  com.mortbay.HTML.Element
 */
public class Tag extends Element
{
    /* ---------------------------------------------------------------- */
    protected String tag;

    /* ---------------------------------------------------------------- */
    public Tag(String tag)
    {
	this.tag=tag;
    }
    
    /* ---------------------------------------------------------------- */
    public void write(Writer out)
	 throws IOException
    {
	out.write('<'+tag+attributes()+'>');
    }
}


// ========================================================================
// Copyright (c) 1996 Intelligent Switched Systems, Sydney
// $Id: PageFactory.java,v 2.1 1999/04/15 00:55:11 gregw Exp $
// ========================================================================

package com.mortbay.HTML;
import java.util.*;
import javax.servlet.*;


/* --------------------------------------------------------------------- */
/** Abstract Page Factory interface
 */
public interface PageFactory
{
    /** Construct a new named page for the request */
    public Page getPage(String name,
			ServletRequest request,
			ServletResponse response);
}


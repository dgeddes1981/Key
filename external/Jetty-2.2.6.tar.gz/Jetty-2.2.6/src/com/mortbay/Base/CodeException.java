// ========================================================================
// Copyright (c) 1997 MortBay Consulting, Sydney
// $Id: CodeException.java,v 2.0 1998/08/07 05:14:27 gregw Exp $
// ========================================================================

package com.mortbay.Base;

/* ------------------------------------------------------------ */
/** Code Exception
 * 
 * Thrown by Code.assert or Code.fail
 * @see Code
 * @version  $Id: CodeException.java,v 2.0 1998/08/07 05:14:27 gregw Exp $
 * @author Greg Wilkins
 */
public class CodeException extends RuntimeException
{
    /* ------------------------------------------------------------ */
    /** Default constructor. 
     */
    public CodeException()
    {
	super();
    }

    public CodeException(String msg)
    {
	super(msg);
    }    
}


// ========================================================================
// Copyright (c) 1998 Mort Bay Consulting (Australia) Pty. Ltd.
// $Id: HeadException.java,v 2.0 1998/08/07 05:16:53 gregw Exp $
// ========================================================================

package com.mortbay.HTTP;

import java.io.IOException;

public class HeadException extends IOException
{
    private HeadException()
    {
	super("HEAD Exception");
    }

    public static final HeadException instance = new HeadException();
};

// ========================================================================
// Copyright (c) 1999 Mort Bay Consulting (Australia) Pty. Ltd.
// $Id: Version.java,v 1.22 1999/09/04 23:58:38 gregw Exp $
// ========================================================================

package com.mortbay.HTTP;

public class Version
{
    public static final String __jetty = "MortBay-Jetty-2.2.6";
};

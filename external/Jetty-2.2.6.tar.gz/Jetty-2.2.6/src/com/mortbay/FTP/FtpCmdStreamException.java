// ===========================================================================
// Copyright (c) 1996 Mort Bay Consulting Pty. Ltd. All rights reserved.
// Copyright (c) 1996 Optimus Solutions Pty. Ltd. All rights reserved.
// $Id: FtpCmdStreamException.java,v 2.0 1998/08/07 05:14:44 gregw Exp $
// ---------------------------------------------------------------------------

package com.mortbay.FTP;

public class FtpCmdStreamException extends FtpException
{
    /* ------------------------------------------------------------------ */
    public String input=null;
    
    
    /* ------------------------------------------------------------------ */
    FtpCmdStreamException()
    {
	super("Unexpected close of FTP command channel");
    }
    
    /* ------------------------------------------------------------------ */
    FtpCmdStreamException(String message, String input)
    {
	super(message);
	this.input=input;
    }
}
